var emdid = eval(txtid);
document.write(emdid.value);